const chat = document.querySelector("#chat");
const history = [];

function addMessage(role, text) {
  const el = document.createElement("div");
  el.className = `msg ${role === "user" ? "user" : "bot"}`;
  el.textContent = text;
  chat.appendChild(el);
  chat.scrollTop = chat.scrollHeight;
}

async function postJSON(url, body) {
  const res = await fetch(url, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(body)
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

document.querySelector("#chatForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const input = document.querySelector("#chatInput");
  const message = input.value.trim();
  if (!message) return;
  input.value = "";
  addMessage("user", message);
  history.push({role: "user", content: message});

  try {
    const data = await postJSON("/api/chat", {message, history});
    addMessage("assistant", data.answer);
    history.push({role: "assistant", content: data.answer});
  } catch (err) {
    addMessage("assistant", "Error: " + err.message);
  }
});

document.querySelector("#assistantBtn").addEventListener("click", async (e) => {
  const button = e.currentTarget;
  const task = document.querySelector("#assistantInput").value.trim();
  const out = document.querySelector("#assistantOutput");
  if (!task) return;
  button.disabled = true; out.textContent = "Thinking…";
  try {
    const data = await postJSON("/api/assistant", {task});
    out.textContent = data.answer;
  } catch (err) {
    out.textContent = "Error: " + err.message;
  } finally { button.disabled = false; }
});

document.querySelector("#generateBtn").addEventListener("click", async (e) => {
  const button = e.currentTarget;
  const prompt = document.querySelector("#imagePrompt").value.trim();
  const result = document.querySelector("#imageResult");
  if (!prompt) return;
  button.disabled = true; result.textContent = "Generating…";
  try {
    const data = await postJSON("/api/generate", {prompt});
    result.innerHTML = `<img src="${data.image}" alt="Generated image">`;
  } catch (err) {
    result.textContent = "Error: " + err.message;
  } finally { button.disabled = false; }
});

document.querySelector("#analyzeBtn").addEventListener("click", async (e) => {
  const button = e.currentTarget;
  const file = document.querySelector("#imageFile").files[0];
  const out = document.querySelector("#visionOutput");
  if (!file) { out.textContent = "Choose an image first."; return; }

  const form = new FormData();
  form.append("image", file);
  button.disabled = true; out.textContent = "Analyzing…";
  try {
    const res = await fetch("/api/analyze", {method: "POST", body: form});
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Request failed");
    out.textContent = data.answer;
  } catch (err) {
    out.textContent = "Error: " + err.message;
  } finally { button.disabled = false; }
});

fetch("/api/health")
  .then(r => r.json())
  .then(data => {
    document.querySelector("#status").textContent =
      data.ok ? "● API ready" : "● Add API key";
  })
  .catch(() => {
    document.querySelector("#status").textContent = "● Server error";
  });

addMessage("assistant", "Hi! I'm AI Hub. Choose a feature and let's get started.");

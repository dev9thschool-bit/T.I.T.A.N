# AI Hub

A simple GitHub-ready AI web app built with Flask and the OpenAI API.

## Features

- 💬 AI chatbot with short conversation history
- 🧠 General AI assistant
- 🎨 AI image generation
- 👁️ Image understanding / object and scene analysis
- 🌐 Responsive web interface

The app uses the OpenAI **Responses API** for text and vision. The old Assistants API is not used.

## 1. Requirements

- Python 3.10+
- An OpenAI API key
- Internet connection

## 2. Install

```bash
git clone YOUR_GITHUB_REPOSITORY_URL
cd AI-HUB

python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Install packages:
```bash
pip install -r requirements.txt
```

## 3. Configure the API key

Copy `.env.example` to `.env`.

Put your key in `.env`:

```env
OPENAI_API_KEY=your_real_key_here
OPENAI_TEXT_MODEL=gpt-6.1-sol
OPENAI_IMAGE_MODEL=gpt-image-2
PORT=5000
```

**Never upload `.env` to GitHub.** It is already excluded by `.gitignore`.

## 4. Run

```bash
python app.py
```

Open:

```text
http://127.0.0.1:5000
```

## 5. GitHub

```bash
git init
git add .
git commit -m "Initial AI Hub"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

## Important

The website is only a frontend/backend project. API usage can incur charges according to your API account and selected models.

For production deployment, add authentication, rate limiting, request-size limits, logging, and HTTPS before exposing the app publicly.

## Project structure

```text
AI-HUB/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── templates/
│   └── index.html
└── static/
    ├── style.css
    └── script.js
```

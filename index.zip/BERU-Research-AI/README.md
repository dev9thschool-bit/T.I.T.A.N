# B.E.R.U. — Research AI

B.E.R.U. is a respectful research assistant web app with:

- Google web search
- AI research reports
- Scientific/general calculations
- AI question answering
- Browser voice wake phrase: "arise"
- Respectful "Master" persona
- Text-to-speech responses

## Setup

1. Install Python 3.10+.
2. Create a virtual environment.
3. Install packages:

```bash
pip install -r requirements.txt
```

4. Copy `.env.example` to `.env`.
5. Add:
   - OpenAI API key
   - Google API key
   - Google Programmable Search Engine ID

6. Start:

```bash
python app.py
```

Open `http://127.0.0.1:5001`.

## Google search setup

Create a Programmable Search Engine and enable the Custom Search JSON API in your Google Cloud project. Put its API key in `GOOGLE_API_KEY` and its search engine ID in `GOOGLE_CSE_ID`.

## Voice wake word

The browser uses the Web Speech API to listen for "arise". Browser support varies, and microphone permission is required. For a reliable always-on wake word, a native desktop/mobile application with a dedicated wake-word engine is recommended.

## Security

Never upload `.env` or API keys to GitHub. This project uses server-side API calls so keys are not exposed in the browser.

## Research caution

Search snippets are evidence, not guaranteed truth. For serious academic work, verify important claims against the original papers, official documentation, datasets, or primary sources.

## GitHub

```bash
git init
git add .
git commit -m "Add B.E.R.U. research AI"
git branch -M main
git remote add origin YOUR_REPOSITORY_URL
git push -u origin main
```

const $ = id => document.getElementById(id);

function setAwake(on) {
  $("awake").textContent = on ? "AWAKENED" : "SLEEPING";
  $("awake").className = on ? "awake" : "sleep";
  $("voiceText").innerHTML = on
    ? "At your command, Master."
    : 'Say <b>“arise”</b> to awaken B.E.R.U.';
}

function speak(text) {
  if ("speechSynthesis" in window) {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 1.0;
    speechSynthesis.speak(u);
  }
}

async function post(url, body) {
  const r = await fetch(url, {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(body)});
  const d = await r.json();
  if (!r.ok) throw new Error(d.error || "Request failed");
  return d;
}

async function searchWeb() {
  const out=$("searchOut"); out.innerHTML="Searching…";
  try {
    const d=await post("/api/search",{query:$("searchQ").value});
    out.innerHTML=d.results.map(x=>`<article><a target="_blank" rel="noopener" href="${x.link}">${x.title}</a><p>${x.snippet}</p></article>`).join("");
    speak(`Research search complete, Master. I found ${d.results.length} sources.`);
  } catch(e){out.textContent=e.message}
}

async function research() {
  const out=$("researchOut"); out.textContent="B.E.R.U. is researching…";
  try {
    const d=await post("/api/research",{topic:$("topic").value});
    out.textContent=d.report;
    speak("The research report is ready, Master.");
  } catch(e){out.textContent=e.message}
}

async function calc() {
  const out=$("calcOut");
  try {
    const d=await post("/api/calculate",{expression:$("expr").value});
    out.textContent=`Result: ${d.result}`;
    speak(`The result is ${d.result}, Master.`);
  } catch(e){out.textContent=e.message}
}

async function ask() {
  const out=$("askOut"); out.textContent="Awaiting result…";
  try {
    const d=await post("/api/ask",{question:$("askQ").value});
    out.textContent=d.answer;
    speak(d.answer.slice(0,250));
  } catch(e){out.textContent=e.message}
}

$("wakeBtn").onclick = () => {
  setAwake(true); speak("I have awakened, Master. I await your command.");
  startListening();
};

function startListening() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) {
    $("voiceText").textContent = "Voice wake-word is not supported by this browser. Use AWAKEN instead.";
    return;
  }
  const recognition = new SR();
  recognition.continuous = true;
  recognition.interimResults = false;
  recognition.lang = "en-US";

  recognition.onresult = event => {
    const text = event.results[event.results.length-1][0].transcript.trim().toLowerCase();
    if (text.includes("arise")) {
      setAwake(true);
      speak("I have awakened, Master. Your command?");
    }
  };
  recognition.onend = () => {
    // Browsers may stop recognition after silence; restart while page is open.
    if (!document.hidden) {
      try { recognition.start(); } catch (_) {}
    }
  };
  try { recognition.start(); } catch (_) {}
}

import os, math, re, json
from flask import Flask, jsonify, render_template, request
from dotenv import load_dotenv
import requests
from openai import OpenAI

load_dotenv()
app = Flask(__name__)

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
GOOGLE_CSE_ID = os.getenv("GOOGLE_CSE_ID")
client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

SYSTEM = """You are B.E.R.U., a highly respectful research assistant.
Address the user as Master. Your personality is inspired by a loyal fantasy
royal guard: respectful, calm, loyal, precise, and helpful, without pretending
to be a real fictional character. Never claim to have abilities you do not have.
For research, distinguish searched facts from calculations and assumptions.
Show formulas and units when doing calculations. Cite web sources supplied to you.
"""

def google_search(query, num=8):
    if not GOOGLE_API_KEY or not GOOGLE_CSE_ID:
        raise RuntimeError("Google Search is not configured. Add GOOGLE_API_KEY and GOOGLE_CSE_ID to .env.")
    r = requests.get(
        "https://www.googleapis.com/customsearch/v1",
        params={"key": GOOGLE_API_KEY, "cx": GOOGLE_CSE_ID, "q": query, "num": min(num, 10)},
        timeout=20,
    )
    r.raise_for_status()
    data = r.json()
    return [{
        "title": x.get("title",""),
        "link": x.get("link",""),
        "snippet": x.get("snippet","")
    } for x in data.get("items", [])]

def calculator(expr):
    # Safe calculator: only arithmetic/functions, no Python names/imports.
    allowed = {"sqrt": math.sqrt, "sin": math.sin, "cos": math.cos,
               "tan": math.tan, "log": math.log, "log10": math.log10,
               "pi": math.pi, "e": math.e, "abs": abs}
    if not re.fullmatch(r"[0-9+\-*/().,%\sA-Za-z_]+", expr):
        raise ValueError("Unsupported characters in expression.")
    expr = expr.replace("^", "**").replace("%", "/100")
    if "**" in expr and re.search(r"\*\*\s*[^0-9.(]", expr):
        raise ValueError("Invalid exponent.")
    return eval(expr, {"__builtins__": {}}, allowed)

@app.get("/")
def home():
    return render_template("index.html")

@app.post("/api/search")
def search():
    try:
        data = request.get_json() or {}
        q = str(data.get("query","")).strip()
        if not q: return jsonify({"error":"Query is required."}), 400
        return jsonify({"results": google_search(q)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.post("/api/calculate")
def calculate():
    try:
        data = request.get_json() or {}
        expr = str(data.get("expression","")).strip()
        if not expr: return jsonify({"error":"Expression is required."}), 400
        return jsonify({"result": calculator(expr)})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.post("/api/research")
def research():
    try:
        if not client:
            return jsonify({"error":"OPENAI_API_KEY is not configured."}), 500
        data = request.get_json() or {}
        topic = str(data.get("topic","")).strip()
        if not topic: return jsonify({"error":"Research topic is required."}), 400

        sources = google_search(topic + " research facts", 8)
        source_text = "\n".join(
            f"[{i+1}] {s['title']}\nURL: {s['link']}\n{s['snippet']}"
            for i,s in enumerate(sources)
        )
        prompt = f"""Master requests a research report on:
{topic}

Use ONLY the supplied search results as web evidence. Do not invent citations.
Create:
1. Executive summary
2. Key findings
3. Important numbers/data
4. Calculations or formulas that are useful
5. Limitations/uncertainties
6. A practical conclusion
7. Sources with their URLs

Search results:
{source_text}
"""
        resp = client.responses.create(model=os.getenv("OPENAI_TEXT_MODEL","gpt-6.1-sol"),
                                       instructions=SYSTEM, input=prompt)
        return jsonify({"report": resp.output_text, "sources": sources})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.post("/api/ask")
def ask():
    try:
        if not client:
            return jsonify({"error":"OPENAI_API_KEY is not configured."}), 500
        data = request.get_json() or {}
        q = str(data.get("question","")).strip()
        if not q: return jsonify({"error":"Question is required."}), 400
        resp = client.responses.create(model=os.getenv("OPENAI_TEXT_MODEL","gpt-6.1-sol"),
                                       instructions=SYSTEM, input=q)
        return jsonify({"answer": resp.output_text})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT","5001")))
